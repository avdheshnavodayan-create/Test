import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // In-memory storage for demo purposes
  const appointments: any[] = [];
  const messages: any[] = [];

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  app.post("/api/appointments", (req, res) => {
    const { name, phone, department, date } = req.body;
    if (!name || !phone) {
      return res.status(400).json({ error: "Name and phone are required" });
    }
    const newAppointment = { id: Date.now(), name, phone, department, date, status: "pending" };
    appointments.push(newAppointment);
    console.log("New Appointment:", newAppointment);
    res.status(201).json({ message: "Appointment booked successfully", appointment: newAppointment });
  });

  app.post("/api/contact", (req, res) => {
    const { name, phone, message } = req.body;
    if (!name || !message) {
      return res.status(400).json({ error: "Name and message are required" });
    }
    const newMessage = { id: Date.now(), name, phone, message, timestamp: new Date() };
    messages.push(newMessage);
    console.log("New Message:", newMessage);
    res.status(201).json({ message: "Message sent successfully" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
