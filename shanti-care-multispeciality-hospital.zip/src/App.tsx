/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Stethoscope, 
  User, 
  Activity, 
  CreditCard, 
  Ambulance, 
  HeartPulse,
  ChevronRight,
  Menu,
  X,
  CheckCircle2,
  Quote
} from 'lucide-react';
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const HOSPITAL_DETAILS = {
  name: "Shanti Care Multispeciality Hospital",
  address: "123, Civil Lines Road, Near Hanuman Mandir, Prayagraj, Uttar Pradesh – 211001, India",
  contact: "+91 532 245 6789",
  email: "info@shanticarehospital.in",
  website: "www.shanticarehospital.in",
  emergency: {
    service: "24x7 Emergency Available",
    ambulance: "+91 8000 123 456"
  },
  opd: [
    { days: "Monday – Saturday", time: "9:00 AM – 7:00 PM" },
    { days: "Sunday", time: "10:00 AM – 2:00 PM" }
  ],
  departments: [
    "General Medicine", "Orthopedics", "Cardiology", "Pediatrics", 
    "Gynecology & Obstetrics", "ENT", "Dermatology"
  ],
  doctors: [
    { name: "Dr. Rajeev Sharma", qualification: "MD – Medicine", role: "General Medicine" },
    { name: "Dr. Neha Verma", qualification: "Gynecologist", role: "Gynecology" },
    { name: "Dr. Amit Singh", qualification: "Orthopedic Surgeon", role: "Orthopedics" }
  ],
  facilities: [
    "ICU & NICU", "Operation Theatre (Modular OT)", "Pharmacy (24x7)", 
    "Diagnostic Lab", "Digital X-ray & Ultrasound", "Private & General Wards"
  ],
  payments: ["Cash", "UPI / Cards", "Insurance (Selected Providers)"]
};

const TESTIMONIALS = [
  {
    name: "Amit Kumar",
    dept: "Cardiology",
    text: "The care I received in the Cardiology department was exceptional. Dr. Rajeev Sharma is truly an expert and explained everything very clearly.",
    rating: 5
  },
  {
    name: "Priya Singh",
    dept: "Orthopedics",
    text: "Excellent facilities and very professional staff. My surgery went smoothly thanks to Dr. Amit Singh. The post-op care was also top-notch.",
    rating: 5
  },
  {
    name: "Rajesh Verma",
    dept: "Pediatrics",
    text: "Best pediatric care in Prayagraj. The doctors are very patient and friendly with kids. My son felt very comfortable during his treatment.",
    rating: 5
  }
];

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState({ title: '', body: '' });
  const [contactForm, setContactForm] = useState({ name: '', phone: '', message: '' });
  const [appointmentForm, setAppointmentForm] = useState({ 
    name: '', 
    phone: '', 
    department: HOSPITAL_DETAILS.departments[0], 
    date: '' 
  });

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(contactForm),
      });
      if (response.ok) {
        setSuccessMessage({ 
          title: 'Message Sent!', 
          body: "We've received your inquiry and will contact you soon." 
        });
        setShowSuccess(true);
        setContactForm({ name: '', phone: '', message: '' });
        setTimeout(() => setShowSuccess(false), 5000);
      }
    } catch (error) {
      console.error('Failed to send message:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAppointmentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const response = await fetch('/api/appointments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(appointmentForm),
      });
      if (response.ok) {
        setSuccessMessage({ 
          title: 'Appointment Booked!', 
          body: "Your appointment request has been submitted successfully." 
        });
        setShowSuccess(true);
        setAppointmentForm({ 
          name: '', 
          phone: '', 
          department: HOSPITAL_DETAILS.departments[0], 
          date: '' 
        });
        setTimeout(() => setShowSuccess(false), 5000);
      }
    } catch (error) {
      console.error('Failed to book appointment:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const fadeIn = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 }
  };

  const staggerContainer = {
    animate: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      {/* Success Notification */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div 
            initial={{ opacity: 0, y: -100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -100 }}
            className="fixed top-6 left-1/2 -translate-x-1/2 z-[100] w-full max-w-md px-4"
          >
            <div className="bg-green-600 text-white p-4 rounded-2xl shadow-2xl flex items-center gap-3">
              <CheckCircle2 className="w-6 h-6 shrink-0" />
              <div>
                <p className="font-bold">{successMessage.title}</p>
                <p className="text-sm opacity-90">{successMessage.body}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Bar */}
      <div className="bg-primary text-primary-foreground py-2 px-4 hidden md:block">
        <div className="max-w-7xl mx-auto flex justify-between items-center text-sm font-medium">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-2">
              <Phone className="w-4 h-4" /> {HOSPITAL_DETAILS.contact}
            </span>
            <span className="flex items-center gap-2">
              <Mail className="w-4 h-4" /> {HOSPITAL_DETAILS.email}
            </span>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="secondary" className="bg-red-500 hover:bg-red-600 text-white border-none animate-pulse">
              Emergency: {HOSPITAL_DETAILS.emergency.ambulance}
            </Badge>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200 shadow-sm">
        <nav className="max-w-7xl mx-auto px-4 h-20 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="bg-primary p-2 rounded-lg">
              <HeartPulse className="w-6 h-6 text-white" />
            </div>
            <span className="font-bold text-xl tracking-tight text-primary">
              Shanti Care
            </span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            <a href="#about" className="text-sm font-semibold hover:text-primary transition-colors">About</a>
            <a href="#departments" className="text-sm font-semibold hover:text-primary transition-colors">Departments</a>
            <a href="#doctors" className="text-sm font-semibold hover:text-primary transition-colors">Doctors</a>
            <a href="#contact" className="text-sm font-semibold hover:text-primary transition-colors">Contact</a>
            <a href="#appointment">
              <Button size="sm" className="font-bold">Book Appointment</Button>
            </a>
          </div>

          {/* Mobile Menu Toggle */}
          <button className="md:hidden p-2" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </nav>

        {/* Mobile Nav */}
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="md:hidden bg-white border-b border-slate-200 px-4 py-6 space-y-4"
          >
            <a href="#about" className="block text-lg font-medium" onClick={() => setIsMenuOpen(false)}>About</a>
            <a href="#departments" className="block text-lg font-medium" onClick={() => setIsMenuOpen(false)}>Departments</a>
            <a href="#doctors" className="block text-lg font-medium" onClick={() => setIsMenuOpen(false)}>Doctors</a>
            <a href="#contact" className="block text-lg font-medium" onClick={() => setIsMenuOpen(false)}>Contact</a>
            <a href="#appointment" onClick={() => setIsMenuOpen(false)}>
              <Button className="w-full font-bold">Book Appointment</Button>
            </a>
          </motion.div>
        )}
      </header>

      <main>
        {/* Hero Section */}
        <section className="relative overflow-hidden bg-white py-20 lg:py-32">
          <div className="max-w-7xl mx-auto px-4 grid lg:grid-cols-2 gap-12 items-center">
            <motion.div {...fadeIn}>
              <Badge variant="outline" className="mb-4 border-primary text-primary px-3 py-1">
                Multispeciality Excellence
              </Badge>
              <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-slate-900 mb-6 leading-[1.1]">
                Your Health, <br />
                <span className="text-primary">Our Priority.</span>
              </h1>
              <p className="text-lg text-slate-600 mb-8 max-w-lg leading-relaxed">
                Shanti Care Multispeciality Hospital provides world-class healthcare services with 
                compassion and expertise. We are dedicated to your well-being 24/7.
              </p>
              <div className="flex flex-wrap gap-4">
                <a href="#departments">
                  <Button size="lg" className="rounded-full px-8 font-bold">
                    Our Services
                  </Button>
                </a>
                <a href="#appointment">
                  <Button size="lg" variant="outline" className="rounded-full px-8 font-bold border-2">
                    Book Appointment
                  </Button>
                </a>
              </div>
              
              <div className="mt-12 flex items-center gap-4 p-4 bg-red-50 border border-red-100 rounded-2xl max-w-sm">
                <div className="bg-red-500 p-3 rounded-xl">
                  <Ambulance className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-xs font-bold text-red-600 uppercase tracking-wider">Emergency Ambulance</p>
                  <p className="text-xl font-black text-red-700">{HOSPITAL_DETAILS.emergency.ambulance}</p>
                </div>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl">
                <img 
                  src="https://picsum.photos/seed/hospital/800/800" 
                  alt="Hospital Building" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-2xl shadow-xl border border-slate-100 hidden sm:block">
                <div className="flex items-center gap-4">
                  <div className="bg-green-100 p-3 rounded-full">
                    <Clock className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-900">OPD Timings</p>
                    <p className="text-xs text-slate-500">Mon-Sat: 9 AM - 7 PM</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Quick Stats/Info */}
        <section className="py-12 bg-slate-50 border-y border-slate-200">
          <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { label: "Departments", value: "7+", icon: Stethoscope },
              { label: "Expert Doctors", value: "15+", icon: User },
              { label: "Emergency", value: "24/7", icon: Activity },
              { label: "Happy Patients", value: "10k+", icon: HeartPulse },
            ].map((stat, i) => (
              <div key={i} className="text-center space-y-2">
                <div className="mx-auto w-12 h-12 bg-white rounded-xl shadow-sm flex items-center justify-center text-primary">
                  <stat.icon className="w-6 h-6" />
                </div>
                <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
                <p className="text-xs font-medium text-slate-500 uppercase tracking-widest">{stat.label}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Appointment Section */}
        <section id="appointment" className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="bg-primary/5 rounded-[3rem] p-8 md:p-16 border border-primary/10">
              <div className="grid lg:grid-cols-2 gap-16 items-center">
                <div>
                  <Badge className="mb-4">Easy Booking</Badge>
                  <h2 className="text-3xl md:text-5xl font-bold text-slate-900 mb-6 leading-tight">
                    Book Your <br />
                    <span className="text-primary">Appointment Online</span>
                  </h2>
                  <p className="text-slate-600 mb-8 max-w-md">
                    Skip the queue and book your consultation with our expert doctors in just a few clicks. 
                    We'll confirm your slot via call.
                  </p>
                  
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">1</div>
                      <p className="font-semibold text-slate-700">Fill the appointment form</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">2</div>
                      <p className="font-semibold text-slate-700">Select your preferred department</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">3</div>
                      <p className="font-semibold text-slate-700">Receive confirmation call</p>
                    </div>
                  </div>
                </div>

                <Card className="shadow-2xl border-none">
                  <CardHeader>
                    <CardTitle>Appointment Form</CardTitle>
                    <CardDescription>All fields are mandatory for booking.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleAppointmentSubmit} className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Full Name</label>
                        <input 
                          required
                          value={appointmentForm.name}
                          onChange={(e) => setAppointmentForm({ ...appointmentForm, name: e.target.value })}
                          className="w-full bg-slate-50 border-slate-200 rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary outline-none transition-all" 
                          placeholder="Enter your name" 
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Phone Number</label>
                        <input 
                          required
                          type="tel"
                          value={appointmentForm.phone}
                          onChange={(e) => setAppointmentForm({ ...appointmentForm, phone: e.target.value })}
                          className="w-full bg-slate-50 border-slate-200 rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary outline-none transition-all" 
                          placeholder="+91 00000 00000" 
                        />
                      </div>
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Department</label>
                          <select 
                            required
                            value={appointmentForm.department}
                            onChange={(e) => setAppointmentForm({ ...appointmentForm, department: e.target.value })}
                            className="w-full bg-slate-50 border-slate-200 rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary outline-none transition-all appearance-none"
                          >
                            {HOSPITAL_DETAILS.departments.map((dept, i) => (
                              <option key={i} value={dept}>{dept}</option>
                            ))}
                          </select>
                        </div>
                        <div className="space-y-2">
                          <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Preferred Date</label>
                          <input 
                            required
                            type="date"
                            value={appointmentForm.date}
                            onChange={(e) => setAppointmentForm({ ...appointmentForm, date: e.target.value })}
                            className="w-full bg-slate-50 border-slate-200 rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary outline-none transition-all" 
                          />
                        </div>
                      </div>
                      <Button 
                        type="submit" 
                        disabled={isSubmitting}
                        className="w-full font-bold py-6 text-lg"
                      >
                        {isSubmitting ? "Processing..." : "Confirm Booking"}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Departments */}
        <section id="departments" className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Our Departments</h2>
              <p className="text-slate-500 max-w-2xl mx-auto">
                Comprehensive medical care across specialized divisions equipped with modern technology.
              </p>
            </div>
            
            <motion.div 
              variants={staggerContainer}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
            >
              {HOSPITAL_DETAILS.departments.map((dept, i) => (
                <motion.div key={i} variants={fadeIn}>
                  <Card className="group hover:border-primary transition-all duration-300 hover:shadow-lg cursor-pointer h-full">
                    <CardHeader>
                      <div className="w-12 h-12 rounded-lg bg-slate-50 flex items-center justify-center mb-4 group-hover:bg-primary/10 transition-colors">
                        <Stethoscope className="w-6 h-6 text-primary" />
                      </div>
                      <CardTitle className="text-lg">{dept}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-slate-500">Expert care and advanced treatment for all patients.</p>
                      <Button variant="link" className="p-0 mt-4 h-auto text-primary font-bold">
                        Learn More <ChevronRight className="w-4 h-4 ml-1" />
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* Doctors Section */}
        <section id="doctors" className="py-24 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Meet Our Experts</h2>
                <p className="text-slate-500 max-w-xl">
                  Our team of highly qualified and experienced doctors is dedicated to providing the best medical care.
                </p>
              </div>
              <Button variant="outline" className="font-bold border-2">View All Doctors</Button>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {HOSPITAL_DETAILS.doctors.map((doctor, i) => (
                <Card key={i} className="overflow-hidden border-none shadow-md">
                  <div className="aspect-[4/5] relative">
                    <img 
                      src={`https://picsum.photos/seed/doctor${i}/600/800`} 
                      alt={doctor.name} 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent" />
                    <div className="absolute bottom-6 left-6 text-white">
                      <p className="text-xl font-bold">{doctor.name}</p>
                      <p className="text-sm opacity-90">{doctor.qualification}</p>
                    </div>
                  </div>
                  <CardContent className="pt-6">
                    <Badge className="mb-2">{doctor.role}</Badge>
                    <p className="text-sm text-slate-500">Specialist in advanced medical procedures and patient care.</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="py-24 bg-primary/5">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-16">
              <Badge variant="outline" className="mb-4 border-primary text-primary">Testimonials</Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">What Our Patients Say</h2>
              <p className="text-slate-500 max-w-2xl mx-auto">
                Real stories from patients who trusted Shanti Care for their medical needs.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {TESTIMONIALS.map((t, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                >
                  <Card className="h-full border-none shadow-sm relative overflow-hidden group hover:shadow-md transition-shadow">
                    <CardContent className="pt-12 pb-8 px-8">
                      <Quote className="absolute top-6 left-6 w-10 h-10 text-primary/10 group-hover:text-primary/20 transition-colors" />
                      <p className="text-slate-600 italic mb-8 relative z-10 leading-relaxed">
                        "{t.text}"
                      </p>
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-lg">
                          {t.name.charAt(0)}
                        </div>
                        <div>
                          <p className="font-bold text-slate-900">{t.name}</p>
                          <p className="text-xs font-medium text-primary uppercase tracking-wider">{t.dept}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Facilities & FAQ */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 grid lg:grid-cols-2 gap-20">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-8">Modern Facilities</h2>
              <div className="grid sm:grid-cols-2 gap-4">
                {HOSPITAL_DETAILS.facilities.map((facility, i) => (
                  <div key={i} className="flex items-center gap-3 p-4 rounded-xl bg-slate-50 border border-slate-100">
                    <div className="w-2 h-2 rounded-full bg-primary" />
                    <span className="text-sm font-semibold text-slate-700">{facility}</span>
                  </div>
                ))}
              </div>
              
              <div className="mt-12 p-8 bg-primary rounded-3xl text-white relative overflow-hidden">
                <div className="relative z-10">
                  <h3 className="text-2xl font-bold mb-4">24/7 Pharmacy & Lab</h3>
                  <p className="opacity-90 mb-6">Our diagnostic services and pharmacy are available around the clock for your convenience.</p>
                  <Button variant="secondary" className="font-bold">Contact Services</Button>
                </div>
                <Activity className="absolute -right-8 -bottom-8 w-48 h-48 opacity-10" />
              </div>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-8">Patient Information</h2>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger className="text-left font-bold">OPD Timings & Appointments</AccordionTrigger>
                  <AccordionContent className="text-slate-500">
                    <div className="space-y-2">
                      {HOSPITAL_DETAILS.opd.map((item, i) => (
                        <p key={i} className="flex justify-between">
                          <span>{item.days}</span>
                          <span className="font-bold text-slate-900">{item.time}</span>
                        </p>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-2">
                  <AccordionTrigger className="text-left font-bold">Payment & Insurance</AccordionTrigger>
                  <AccordionContent className="text-slate-500">
                    <p className="mb-4">We accept multiple payment modes for a hassle-free experience:</p>
                    <div className="flex flex-wrap gap-2">
                      {HOSPITAL_DETAILS.payments.map((p, i) => (
                        <Badge key={i} variant="secondary">{p}</Badge>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-3">
                  <AccordionTrigger className="text-left font-bold">Emergency Admission Process</AccordionTrigger>
                  <AccordionContent className="text-slate-500">
                    Our emergency department is open 24x7. Patients are triaged immediately upon arrival. 
                    Please bring a valid ID and any previous medical records if available.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-24 bg-slate-900 text-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid lg:grid-cols-3 gap-12">
              <div className="lg:col-span-1">
                <div className="flex items-center gap-2 mb-8">
                  <div className="bg-primary p-2 rounded-lg">
                    <HeartPulse className="w-6 h-6 text-white" />
                  </div>
                  <span className="font-bold text-2xl tracking-tight">
                    Shanti Care
                  </span>
                </div>
                <p className="text-slate-400 mb-8 leading-relaxed">
                  Leading the way in medical excellence. We provide comprehensive healthcare 
                  solutions with a patient-first approach.
                </p>
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="bg-slate-800 p-3 rounded-xl h-fit">
                      <MapPin className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-bold mb-1">Our Location</p>
                      <p className="text-sm text-slate-400">{HOSPITAL_DETAILS.address}</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="bg-slate-800 p-3 rounded-xl h-fit">
                      <Phone className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-bold mb-1">Call Us</p>
                      <p className="text-sm text-slate-400">{HOSPITAL_DETAILS.contact}</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="bg-slate-800 p-3 rounded-xl h-fit">
                      <Mail className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-bold mb-1">Email Us</p>
                      <p className="text-sm text-slate-400">{HOSPITAL_DETAILS.email}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-2">
                <Card className="bg-slate-800 border-slate-700 text-white">
                  <CardHeader>
                    <CardTitle>Send us a Message</CardTitle>
                    <CardDescription className="text-slate-400">We'll get back to you as soon as possible.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleContactSubmit} className="space-y-4">
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Full Name</label>
                          <input 
                            required
                            value={contactForm.name}
                            onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                            className="w-full bg-slate-900 border-slate-700 rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary outline-none transition-all" 
                            placeholder="John Doe" 
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Phone Number</label>
                          <input 
                            required
                            value={contactForm.phone}
                            onChange={(e) => setContactForm({ ...contactForm, phone: e.target.value })}
                            className="w-full bg-slate-900 border-slate-700 rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary outline-none transition-all" 
                            placeholder="+91 00000 00000" 
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Message</label>
                        <textarea 
                          required
                          value={contactForm.message}
                          onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                          className="w-full bg-slate-900 border-slate-700 rounded-lg p-3 text-sm h-32 focus:ring-2 focus:ring-primary outline-none transition-all" 
                          placeholder="How can we help you?" 
                        />
                      </div>
                      <Button 
                        type="submit" 
                        disabled={isSubmitting}
                        className="w-full font-bold py-6"
                      >
                        {isSubmitting ? "Sending..." : "Send Message"}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </div>
            </div>

            <Separator className="my-12 bg-slate-800" />

            <div className="flex flex-col md:flex-row justify-between items-center gap-6 text-sm text-slate-500">
              <p>© {new Date().getFullYear()} {HOSPITAL_DETAILS.name}. All rights reserved.</p>
              <div className="flex gap-8">
                <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
                <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Sticky Emergency Button Mobile */}
      <div className="md:hidden fixed bottom-6 right-6 z-50">
        <Button size="icon" className="w-14 h-14 rounded-full shadow-2xl bg-red-500 hover:bg-red-600">
          <Phone className="w-6 h-6" />
        </Button>
      </div>
    </div>
  );
}
